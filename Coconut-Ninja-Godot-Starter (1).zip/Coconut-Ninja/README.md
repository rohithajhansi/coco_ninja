# Coconut Ninja

A 2D Godot 4 game prototype for the hackathon theme **Bounce Back**.

## Open the project

1. Extract this folder into your team's cloned GitHub repository.
2. Open Godot 4.x.
3. Choose **Import**.
4. Select the `project.godot` file in this folder.
5. Choose **Import & Edit**.
6. Press **F6** to run the current scene, or **F5** to run the project.

## Project structure

- `scenes/` — Godot scenes (`.tscn`)
- `scripts/` — GDScript files (`.gd`)
- `assets/sprites/` — character, coconut, trampoline, and background art
- `assets/audio/` — music and sound effects
- `assets/fonts/` — optional fonts

## Team GitHub workflow

Before starting work, use GitHub Desktop to **Fetch origin** and **Pull origin**.
After making changes, save your Godot files, review the Changes tab, commit with a clear message, and **Push origin**.

Avoid having two people edit the same scene or script at the same time.
