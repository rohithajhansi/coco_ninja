Place sprite images and textures here.
