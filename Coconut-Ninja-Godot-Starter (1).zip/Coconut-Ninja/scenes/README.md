Place your Godot scenes here. Suggested future scenes: player.tscn, coconut.tscn, trampoline.tscn, game_over.tscn.
