Place your GDScript files here. Suggested future scripts: player.gd, coconut.gd, sword.gd, game_manager.gd.
